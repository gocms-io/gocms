import React from 'react'
import { IndexRoute } from 'react-router'
import HomePage from './homePage.container';

export default (
    <IndexRoute component={HomePage}/>
)
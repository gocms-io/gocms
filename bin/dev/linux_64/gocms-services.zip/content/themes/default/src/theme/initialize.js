import theme from './config/init';

export default theme
